###### Class kotlin.contracts.ConditionalEffect (kotlin.contracts.ConditionalEffect)
.class public interface abstract Lkotlin/contracts/ConditionalEffect;
.super Ljava/lang/Object;
.source "Effect.kt"

# interfaces
.implements Lkotlin/contracts/Effect;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0008g\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"
    }
    d2 = {
        "Lkotlin/contracts/ConditionalEffect;",
        "Lkotlin/contracts/Effect;",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation
