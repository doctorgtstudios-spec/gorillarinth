###### Class kotlin.collections.ArraysKt__ArraysKt (kotlin.collections.ArraysKt__ArraysKt)
.class Lkotlin/collections/ArraysKt__ArraysKt;
.super Lkotlin/collections/ArraysKt__ArraysJVMKt;
.source "Arrays.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nArrays.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Arrays.kt\nkotlin/collections/ArraysKt__ArraysKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,165:1\n1#2:166\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000H\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0011\n\u0002\u0008\u0004\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010!\n\u0002\u0008\u0003\n\u0002\u0010 \n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u001a5\u0010\u0000\u001a\u00020\u0001\"\u0004\u0008\u0000\u0010\u0002*\u000c\u0012\u0006\u0008\u0001\u0012\u0002H\u0002\u0018\u00010\u00032\u0010\u0010\u0004\u001a\u000c\u0012\u0006\u0008\u0001\u0012\u0002H\u0002\u0018\u00010\u0003H\u0001\u00a2\u0006\u0004\u0008\u0005\u0010\u0006\u001a#\u0010\u0007\u001a\u00020\u0008\"\u0004\u0008\u0000\u0010\u0002*\u000c\u0012\u0006\u0008\u0001\u0012\u0002H\u0002\u0018\u00010\u0003H\u0001\u00a2\u0006\u0004\u0008\t\u0010\n\u001a?\u0010\u000b\u001a\u00020\u000c\"\u0004\u0008\u0000\u0010\u0002*\n\u0012\u0006\u0008\u0001\u0012\u0002H\u00020\u00032\n\u0010\r\u001a\u00060\u000ej\u0002`\u000f2\u0010\u0010\u0010\u001a\u000c\u0012\u0008\u0012\u0006\u0012\u0002\u0008\u00030\u00030\u0011H\u0002\u00a2\u0006\u0004\u0008\u0012\u0010\u0013\u001a+\u0010\u0014\u001a\u0008\u0012\u0004\u0012\u0002H\u00020\u0015\"\u0004\u0008\u0000\u0010\u0002*\u0012\u0012\u000e\u0008\u0001\u0012\n\u0012\u0006\u0008\u0001\u0012\u0002H\u00020\u00030\u0003\u00a2\u0006\u0002\u0010\u0016\u001aH\u0010\u0017\u001a\u0002H\u0018\"\u0010\u0008\u0000\u0010\u0019*\u0006\u0012\u0002\u0008\u00030\u0003*\u0002H\u0018\"\u0004\u0008\u0001\u0010\u0018*\u0002H\u00192\u000c\u0010\u001a\u001a\u0008\u0012\u0004\u0012\u0002H\u00180\u001bH\u0087\u0008\u00f8\u0001\u0000\u0082\u0002\n\n\u0008\u0008\u0001\u0012\u0002\u0010\u0001 \u0000\u00a2\u0006\u0002\u0010\u001c\u001a)\u0010\u001d\u001a\u00020\u0001*\u0008\u0012\u0002\u0008\u0003\u0018\u00010\u0003H\u0087\u0008\u0082\u0002\u000e\n\u000c\u0008\u0000\u0012\u0002\u0018\u0001\u001a\u0004\u0008\u0003\u0010\u0000\u00a2\u0006\u0002\u0010\u001e\u001aG\u0010\u001f\u001a\u001a\u0012\n\u0012\u0008\u0012\u0004\u0012\u0002H\u00020\u0015\u0012\n\u0012\u0008\u0012\u0004\u0012\u0002H\u00180\u00150 \"\u0004\u0008\u0000\u0010\u0002\"\u0004\u0008\u0001\u0010\u0018*\u0016\u0012\u0012\u0008\u0001\u0012\u000e\u0012\u0004\u0012\u0002H\u0002\u0012\u0004\u0012\u0002H\u00180 0\u0003\u00a2\u0006\u0002\u0010!\u0082\u0002\u0007\n\u0005\u0008\u009920\u0001\u00a8\u0006\""
    }
    d2 = {
        "contentDeepEqualsImpl",
        "",
        "T",
        "",
        "other",
        "contentDeepEquals",
        "([Ljava/lang/Object;[Ljava/lang/Object;)Z",
        "contentDeepToStringImpl",
        "",
        "contentDeepToString",
        "([Ljava/lang/Object;)Ljava/lang/String;",
        "contentDeepToStringInternal",
        "",
        "result",
        "Ljava/lang/StringBuilder;",
        "Lkotlin/text/StringBuilder;",
        "processed",
        "",
        "contentDeepToStringInternal$ArraysKt__ArraysKt",
        "([Ljava/lang/Object;Ljava/lang/StringBuilder;Ljava/util/List;)V",
        "flatten",
        "",
        "([[Ljava/lang/Object;)Ljava/util/List;",
        "ifEmpty",
        "R",
        "C",
        "defaultValue",
        "Lkotlin/Function0;",
        "([Ljava/lang/Object;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;",
        "isNullOrEmpty",
        "([Ljava/lang/Object;)Z",
        "unzip",
        "Lkotlin/Pair;",
        "([Lkotlin/Pair;)Lkotlin/Pair;",
        "kotlin-stdlib"
    }
    k = 0x5
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x31
    xs = "kotlin/collections/ArraysKt"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lkotlin/collections/ArraysKt__ArraysJVMKt;-><init>()V

    return-void
.end method

.method public static final contentDeepEquals([Ljava/lang/Object;[Ljava/lang/Object;)Z
    .registers 10
    .param p0, "$this$contentDeepEqualsImpl"    # [Ljava/lang/Object;
    .param p1, "other"    # [Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;[TT;)Z"
        }
    .end annotation

    .line 80
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    .line 81
    :cond_4
    const/4 v1, 0x0

    if-eqz p0, :cond_160

    if-eqz p1, :cond_160

    array-length v2, p0

    array-length v3, p1

    if-eq v2, v3, :cond_f

    goto/16 :goto_160

    .line 83
    :cond_f
    const/4 v2, 0x0

    .local v2, "i":I
    array-length v3, p0

    :goto_11
    if-ge v2, v3, :cond_15f

    .line 84
    aget-object v4, p0, v2

    .line 85
    .local v4, "v1":Ljava/lang/Object;
    aget-object v5, p1, v2

    .line 87
    .local v5, "v2":Ljava/lang/Object;
    if-ne v4, v5, :cond_1b

    .line 88
    goto/16 :goto_15a

    .line 89
    :cond_1b
    if-eqz v4, :cond_15e

    if-nez v5, :cond_21

    goto/16 :goto_15e

    .line 93
    :cond_21
    nop

    .line 94
    instance-of v6, v4, [Ljava/lang/Object;

    if-eqz v6, :cond_37

    instance-of v6, v5, [Ljava/lang/Object;

    if-eqz v6, :cond_37

    move-object v6, v4

    check-cast v6, [Ljava/lang/Object;

    move-object v7, v5

    check-cast v7, [Ljava/lang/Object;

    invoke-static {v6, v7}, Lkotlin/collections/ArraysKt;->contentDeepEquals([Ljava/lang/Object;[Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 95
    :cond_37
    instance-of v6, v4, [B

    if-eqz v6, :cond_4c

    instance-of v6, v5, [B

    if-eqz v6, :cond_4c

    move-object v6, v4

    check-cast v6, [B

    move-object v7, v5

    check-cast v7, [B

    invoke-static {v6, v7}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 96
    :cond_4c
    instance-of v6, v4, [S

    if-eqz v6, :cond_61

    instance-of v6, v5, [S

    if-eqz v6, :cond_61

    move-object v6, v4

    check-cast v6, [S

    move-object v7, v5

    check-cast v7, [S

    invoke-static {v6, v7}, Ljava/util/Arrays;->equals([S[S)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 97
    :cond_61
    instance-of v6, v4, [I

    if-eqz v6, :cond_76

    instance-of v6, v5, [I

    if-eqz v6, :cond_76

    move-object v6, v4

    check-cast v6, [I

    move-object v7, v5

    check-cast v7, [I

    invoke-static {v6, v7}, Ljava/util/Arrays;->equals([I[I)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 98
    :cond_76
    instance-of v6, v4, [J

    if-eqz v6, :cond_8b

    instance-of v6, v5, [J

    if-eqz v6, :cond_8b

    move-object v6, v4

    check-cast v6, [J

    move-object v7, v5

    check-cast v7, [J

    invoke-static {v6, v7}, Ljava/util/Arrays;->equals([J[J)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 99
    :cond_8b
    instance-of v6, v4, [F

    if-eqz v6, :cond_a0

    instance-of v6, v5, [F

    if-eqz v6, :cond_a0

    move-object v6, v4

    check-cast v6, [F

    move-object v7, v5

    check-cast v7, [F

    invoke-static {v6, v7}, Ljava/util/Arrays;->equals([F[F)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 100
    :cond_a0
    instance-of v6, v4, [D

    if-eqz v6, :cond_b5

    instance-of v6, v5, [D

    if-eqz v6, :cond_b5

    move-object v6, v4

    check-cast v6, [D

    move-object v7, v5

    check-cast v7, [D

    invoke-static {v6, v7}, Ljava/util/Arrays;->equals([D[D)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 101
    :cond_b5
    instance-of v6, v4, [C

    if-eqz v6, :cond_ca

    instance-of v6, v5, [C

    if-eqz v6, :cond_ca

    move-object v6, v4

    check-cast v6, [C

    move-object v7, v5

    check-cast v7, [C

    invoke-static {v6, v7}, Ljava/util/Arrays;->equals([C[C)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 102
    :cond_ca
    instance-of v6, v4, [Z

    if-eqz v6, :cond_df

    instance-of v6, v5, [Z

    if-eqz v6, :cond_df

    move-object v6, v4

    check-cast v6, [Z

    move-object v7, v5

    check-cast v7, [Z

    invoke-static {v6, v7}, Ljava/util/Arrays;->equals([Z[Z)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 104
    :cond_df
    instance-of v6, v4, Lkotlin/UByteArray;

    if-eqz v6, :cond_fc

    instance-of v6, v5, Lkotlin/UByteArray;

    if-eqz v6, :cond_fc

    move-object v6, v4

    check-cast v6, Lkotlin/UByteArray;

    invoke-virtual {v6}, Lkotlin/UByteArray;->unbox-impl()[B

    move-result-object v6

    move-object v7, v5

    check-cast v7, Lkotlin/UByteArray;

    invoke-virtual {v7}, Lkotlin/UByteArray;->unbox-impl()[B

    move-result-object v7

    invoke-static {v6, v7}, Lkotlin/collections/unsigned/UArraysKt;->contentEquals-kV0jMPg([B[B)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 105
    :cond_fc
    instance-of v6, v4, Lkotlin/UShortArray;

    if-eqz v6, :cond_119

    instance-of v6, v5, Lkotlin/UShortArray;

    if-eqz v6, :cond_119

    move-object v6, v4

    check-cast v6, Lkotlin/UShortArray;

    invoke-virtual {v6}, Lkotlin/UShortArray;->unbox-impl()[S

    move-result-object v6

    move-object v7, v5

    check-cast v7, Lkotlin/UShortArray;

    invoke-virtual {v7}, Lkotlin/UShortArray;->unbox-impl()[S

    move-result-object v7

    invoke-static {v6, v7}, Lkotlin/collections/unsigned/UArraysKt;->contentEquals-FGO6Aew([S[S)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 106
    :cond_119
    instance-of v6, v4, Lkotlin/UIntArray;

    if-eqz v6, :cond_136

    instance-of v6, v5, Lkotlin/UIntArray;

    if-eqz v6, :cond_136

    move-object v6, v4

    check-cast v6, Lkotlin/UIntArray;

    invoke-virtual {v6}, Lkotlin/UIntArray;->unbox-impl()[I

    move-result-object v6

    move-object v7, v5

    check-cast v7, Lkotlin/UIntArray;

    invoke-virtual {v7}, Lkotlin/UIntArray;->unbox-impl()[I

    move-result-object v7

    invoke-static {v6, v7}, Lkotlin/collections/unsigned/UArraysKt;->contentEquals-KJPZfPQ([I[I)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 107
    :cond_136
    instance-of v6, v4, Lkotlin/ULongArray;

    if-eqz v6, :cond_153

    instance-of v6, v5, Lkotlin/ULongArray;

    if-eqz v6, :cond_153

    move-object v6, v4

    check-cast v6, Lkotlin/ULongArray;

    invoke-virtual {v6}, Lkotlin/ULongArray;->unbox-impl()[J

    move-result-object v6

    move-object v7, v5

    check-cast v7, Lkotlin/ULongArray;

    invoke-virtual {v7}, Lkotlin/ULongArray;->unbox-impl()[J

    move-result-object v7

    invoke-static {v6, v7}, Lkotlin/collections/unsigned/UArraysKt;->contentEquals-lec5QzE([J[J)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 109
    :cond_153
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_15a

    return v1

    .line 83
    .end local v4    # "v1":Ljava/lang/Object;
    .end local v5    # "v2":Ljava/lang/Object;
    :cond_15a
    :goto_15a
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_11

    .line 90
    .restart local v4    # "v1":Ljava/lang/Object;
    .restart local v5    # "v2":Ljava/lang/Object;
    :cond_15e
    :goto_15e
    return v1

    .line 113
    .end local v2    # "i":I
    .end local v4    # "v1":Ljava/lang/Object;
    .end local v5    # "v2":Ljava/lang/Object;
    :cond_15f
    return v0

    .line 81
    :cond_160
    :goto_160
    return v1
.end method

.method public static final contentDeepToString([Ljava/lang/Object;)Ljava/lang/String;
    .registers 6
    .param p0, "$this$contentDeepToStringImpl"    # [Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 121
    if-nez p0, :cond_5

    const-string v0, "null"

    return-object v0

    .line 122
    :cond_5
    array-length v0, p0

    const v1, 0x19999999

    invoke-static {v0, v1}, Lkotlin/ranges/RangesKt;->coerceAtMost(II)I

    move-result v0

    mul-int/lit8 v0, v0, 0x5

    add-int/lit8 v0, v0, 0x2

    .line 123
    .local v0, "length":I
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    move-object v2, v1

    .local v2, "$this$contentDeepToStringImpl_u24lambda_u243":Ljava/lang/StringBuilder;
    const/4 v3, 0x0

    .line 124
    .local v3, "$i$a$-buildString-ArraysKt__ArraysKt$contentDeepToStringImpl$1":I
    new-instance v4, Ljava/util/ArrayList;

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    check-cast v4, Ljava/util/List;

    invoke-static {p0, v2, v4}, Lkotlin/collections/ArraysKt__ArraysKt;->contentDeepToStringInternal$ArraysKt__ArraysKt([Ljava/lang/Object;Ljava/lang/StringBuilder;Ljava/util/List;)V

    .line 125
    nop

    .line 123
    .end local v2    # "$this$contentDeepToStringImpl_u24lambda_u243":Ljava/lang/StringBuilder;
    .end local v3    # "$i$a$-buildString-ArraysKt__ArraysKt$contentDeepToStringImpl$1":I
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "toString(...)"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v1
.end method

.method private static final contentDeepToStringInternal$ArraysKt__ArraysKt([Ljava/lang/Object;Ljava/lang/StringBuilder;Ljava/util/List;)V
    .registers 8
    .param p0, "$this$contentDeepToStringInternal"    # [Ljava/lang/Object;
    .param p1, "result"    # Ljava/lang/StringBuilder;
    .param p2, "processed"    # Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([TT;",
            "Ljava/lang/StringBuilder;",
            "Ljava/util/List<",
            "[",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    .line 130
    invoke-interface {p2, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_c

    .line 131
    const-string v0, "[...]"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 132
    return-void

    .line 134
    :cond_c
    invoke-interface {p2, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 135
    const/16 v0, 0x5b

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 137
    const/4 v0, 0x0

    .local v0, "i":I
    array-length v1, p0

    :goto_16
    if-ge v0, v1, :cond_130

    .line 138
    if-eqz v0, :cond_1f

    .line 139
    const-string v2, ", "

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 141
    :cond_1f
    aget-object v2, p0, v0

    .line 142
    .local v2, "element":Ljava/lang/Object;
    nop

    .line 143
    if-nez v2, :cond_2b

    const-string v3, "null"

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_12c

    .line 144
    :cond_2b
    instance-of v3, v2, [Ljava/lang/Object;

    if-eqz v3, :cond_37

    move-object v3, v2

    check-cast v3, [Ljava/lang/Object;

    invoke-static {v3, p1, p2}, Lkotlin/collections/ArraysKt__ArraysKt;->contentDeepToStringInternal$ArraysKt__ArraysKt([Ljava/lang/Object;Ljava/lang/StringBuilder;Ljava/util/List;)V

    goto/16 :goto_12c

    .line 145
    :cond_37
    instance-of v3, v2, [B

    const-string v4, "toString(...)"

    if-eqz v3, :cond_4c

    move-object v3, v2

    check-cast v3, [B

    invoke-static {v3}, Ljava/util/Arrays;->toString([B)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_12c

    .line 146
    :cond_4c
    instance-of v3, v2, [S

    if-eqz v3, :cond_5f

    move-object v3, v2

    check-cast v3, [S

    invoke-static {v3}, Ljava/util/Arrays;->toString([S)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_12c

    .line 147
    :cond_5f
    instance-of v3, v2, [I

    if-eqz v3, :cond_72

    move-object v3, v2

    check-cast v3, [I

    invoke-static {v3}, Ljava/util/Arrays;->toString([I)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_12c

    .line 148
    :cond_72
    instance-of v3, v2, [J

    if-eqz v3, :cond_85

    move-object v3, v2

    check-cast v3, [J

    invoke-static {v3}, Ljava/util/Arrays;->toString([J)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_12c

    .line 149
    :cond_85
    instance-of v3, v2, [F

    if-eqz v3, :cond_98

    move-object v3, v2

    check-cast v3, [F

    invoke-static {v3}, Ljava/util/Arrays;->toString([F)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_12c

    .line 150
    :cond_98
    instance-of v3, v2, [D

    if-eqz v3, :cond_ab

    move-object v3, v2

    check-cast v3, [D

    invoke-static {v3}, Ljava/util/Arrays;->toString([D)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_12c

    .line 151
    :cond_ab
    instance-of v3, v2, [C

    if-eqz v3, :cond_be

    move-object v3, v2

    check-cast v3, [C

    invoke-static {v3}, Ljava/util/Arrays;->toString([C)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto/16 :goto_12c

    .line 152
    :cond_be
    instance-of v3, v2, [Z

    if-eqz v3, :cond_d0

    move-object v3, v2

    check-cast v3, [Z

    invoke-static {v3}, Ljava/util/Arrays;->toString([Z)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_12c

    .line 154
    :cond_d0
    instance-of v3, v2, Lkotlin/UByteArray;

    const/4 v4, 0x0

    if-eqz v3, :cond_e6

    move-object v3, v2

    check-cast v3, Lkotlin/UByteArray;

    if-eqz v3, :cond_de

    invoke-virtual {v3}, Lkotlin/UByteArray;->unbox-impl()[B

    move-result-object v4

    :cond_de
    invoke-static {v4}, Lkotlin/collections/unsigned/UArraysKt;->contentToString-2csIQuQ([B)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_12c

    .line 155
    :cond_e6
    instance-of v3, v2, Lkotlin/UShortArray;

    if-eqz v3, :cond_fb

    move-object v3, v2

    check-cast v3, Lkotlin/UShortArray;

    if-eqz v3, :cond_f3

    invoke-virtual {v3}, Lkotlin/UShortArray;->unbox-impl()[S

    move-result-object v4

    :cond_f3
    invoke-static {v4}, Lkotlin/collections/unsigned/UArraysKt;->contentToString-d-6D3K8([S)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_12c

    .line 156
    :cond_fb
    instance-of v3, v2, Lkotlin/UIntArray;

    if-eqz v3, :cond_110

    move-object v3, v2

    check-cast v3, Lkotlin/UIntArray;

    if-eqz v3, :cond_108

    invoke-virtual {v3}, Lkotlin/UIntArray;->unbox-impl()[I

    move-result-object v4

    :cond_108
    invoke-static {v4}, Lkotlin/collections/unsigned/UArraysKt;->contentToString-XUkPCBk([I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_12c

    .line 157
    :cond_110
    instance-of v3, v2, Lkotlin/ULongArray;

    if-eqz v3, :cond_125

    move-object v3, v2

    check-cast v3, Lkotlin/ULongArray;

    if-eqz v3, :cond_11d

    invoke-virtual {v3}, Lkotlin/ULongArray;->unbox-impl()[J

    move-result-object v4

    :cond_11d
    invoke-static {v4}, Lkotlin/collections/unsigned/UArraysKt;->contentToString-uLth9ew([J)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_12c

    .line 159
    :cond_125
    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    .end local v2    # "element":Ljava/lang/Object;
    :goto_12c
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_16

    .line 163
    .end local v0    # "i":I
    :cond_130
    const/16 v0, 0x5d

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 164
    invoke-static {p2}, Lkotlin/collections/CollectionsKt;->getLastIndex(Ljava/util/List;)I

    move-result v0

    invoke-interface {p2, v0}, Ljava/util/List;->remove(I)Ljava/lang/Object;

    .line 165
    return-void
.end method

.method public static final flatten([[Ljava/lang/Object;)Ljava/util/List;
    .registers 8
    .param p0, "$this$flatten"    # [[Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">([[TT;)",
            "Ljava/util/List<",
            "TT;>;"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    move-object v0, p0

    check-cast v0, [Ljava/lang/Object;

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    move v4, v3

    :goto_c
    if-ge v3, v1, :cond_19

    aget-object v5, v0, v3

    check-cast v5, [Ljava/lang/Object;

    .line 166
    nop

    .local v5, "it":[Ljava/lang/Object;
    const/4 v6, 0x0

    .line 20
    .local v6, "$i$a$-sumOfInt-ArraysKt__ArraysKt$flatten$result$1":I
    array-length v5, v5

    .end local v5    # "it":[Ljava/lang/Object;
    .end local v6    # "$i$a$-sumOfInt-ArraysKt__ArraysKt$flatten$result$1":I
    add-int/2addr v4, v5

    add-int/lit8 v3, v3, 0x1

    goto :goto_c

    :cond_19
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 21
    .local v0, "result":Ljava/util/ArrayList;
    move-object v1, p0

    check-cast v1, [Ljava/lang/Object;

    array-length v1, v1

    :goto_22
    if-ge v2, v1, :cond_2f

    aget-object v3, p0, v2

    .line 22
    .local v3, "element":[Ljava/lang/Object;
    move-object v4, v0

    check-cast v4, Ljava/util/Collection;

    invoke-static {v4, v3}, Lkotlin/collections/CollectionsKt;->addAll(Ljava/util/Collection;[Ljava/lang/Object;)Z

    .line 21
    .end local v3    # "element":[Ljava/lang/Object;
    add-int/lit8 v2, v2, 0x1

    goto :goto_22

    .line 24
    :cond_2f
    move-object v1, v0

    check-cast v1, Ljava/util/List;

    return-object v1
.end method

.method private static final ifEmpty([Ljava/lang/Object;Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;
    .registers 3
    .param p0, "$this$ifEmpty"    # [Ljava/lang/Object;
    .param p1, "defaultValue"    # Lkotlin/jvm/functions/Function0;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<C:[",
            "Ljava/lang/Object;",
            ":TR;R:",
            "Ljava/lang/Object;",
            ">(TC;",
            "Lkotlin/jvm/functions/Function0<",
            "+TR;>;)TR;"
        }
    .end annotation

    const-string v0, "defaultValue"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 67
    nop

    .line 70
    array-length v0, p0

    if-nez v0, :cond_b

    const/4 v0, 0x1

    goto :goto_c

    :cond_b
    const/4 v0, 0x0

    :goto_c
    if-eqz v0, :cond_13

    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    move-result-object v0

    goto :goto_14

    :cond_13
    move-object v0, p0

    :goto_14
    return-object v0
.end method

.method private static final isNullOrEmpty([Ljava/lang/Object;)Z
    .registers 4
    .param p0, "$this$isNullOrEmpty"    # [Ljava/lang/Object;

    .line 50
    nop

    .line 54
    const/4 v0, 0x1

    if-eqz p0, :cond_f

    array-length v1, p0

    const/4 v2, 0x0

    if-nez v1, :cond_a

    move v1, v0

    goto :goto_b

    :cond_a
    move v1, v2

    :goto_b
    if-eqz v1, :cond_e

    goto :goto_f

    :cond_e
    move v0, v2

    :cond_f
    :goto_f
    return v0
.end method

.method public static final unzip([Lkotlin/Pair;)Lkotlin/Pair;
    .registers 7
    .param p0, "$this$unzip"    # [Lkotlin/Pair;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            "R:",
            "Ljava/lang/Object;",
            ">([",
            "Lkotlin/Pair<",
            "+TT;+TR;>;)",
            "Lkotlin/Pair<",
            "Ljava/util/List<",
            "TT;>;",
            "Ljava/util/List<",
            "TR;>;>;"
        }
    .end annotation

    const-string v0, "<this>"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    new-instance v0, Ljava/util/ArrayList;

    array-length v1, p0

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    .line 35
    .local v0, "listT":Ljava/util/ArrayList;
    new-instance v1, Ljava/util/ArrayList;

    array-length v2, p0

    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 36
    .local v1, "listR":Ljava/util/ArrayList;
    array-length v2, p0

    const/4 v3, 0x0

    :goto_13
    if-ge v3, v2, :cond_28

    aget-object v4, p0, v3

    .line 37
    .local v4, "pair":Lkotlin/Pair;
    invoke-virtual {v4}, Lkotlin/Pair;->getFirst()Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 38
    invoke-virtual {v4}, Lkotlin/Pair;->getSecond()Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    .end local v4    # "pair":Lkotlin/Pair;
    add-int/lit8 v3, v3, 0x1

    goto :goto_13

    .line 40
    :cond_28
    invoke-static {v0, v1}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    return-object v2
.end method
