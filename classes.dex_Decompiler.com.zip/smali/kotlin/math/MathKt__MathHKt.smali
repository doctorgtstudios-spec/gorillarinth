###### Class kotlin.math.MathKt__MathHKt (kotlin.math.MathKt__MathHKt)
.class Lkotlin/math/MathKt__MathHKt;
.super Ljava/lang/Object;
.source "MathH.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0006\n\u0002\u0008\u0005\"\u0016\u0010\u0000\u001a\u00020\u00018\u0006X\u0087T\u00a2\u0006\u0008\n\u0000\u0012\u0004\u0008\u0002\u0010\u0003\"\u0016\u0010\u0004\u001a\u00020\u00018\u0006X\u0087T\u00a2\u0006\u0008\n\u0000\u0012\u0004\u0008\u0005\u0010\u0003\u00a8\u0006\u0006"
    }
    d2 = {
        "E",
        "",
        "getE$annotations",
        "()V",
        "PI",
        "getPI$annotations",
        "kotlin-stdlib"
    }
    k = 0x5
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x31
    xs = "kotlin/math/MathKt"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic getE$annotations()V
    .registers 0

    return-void
.end method

.method public static synthetic getPI$annotations()V
    .registers 0

    return-void
.end method
