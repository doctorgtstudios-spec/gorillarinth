###### Class kotlin.jvm.functions.Function5 (kotlin.jvm.functions.Function5)
.class public interface abstract Lkotlin/jvm/functions/Function5;
.super Ljava/lang/Object;
.source "Functions.kt"

# interfaces
.implements Lkotlin/Function;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<P1:",
        "Ljava/lang/Object;",
        "P2:",
        "Ljava/lang/Object;",
        "P3:",
        "Ljava/lang/Object;",
        "P4:",
        "Ljava/lang/Object;",
        "P5:",
        "Ljava/lang/Object;",
        "R:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;",
        "Lkotlin/Function<",
        "TR;>;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0008\u0006\n\u0002\u0018\u0002\n\u0002\u0008\u0008\u0008f\u0018\u0000*\u0006\u0008\u0000\u0010\u0001 \u0000*\u0006\u0008\u0001\u0010\u0002 \u0000*\u0006\u0008\u0002\u0010\u0003 \u0000*\u0006\u0008\u0003\u0010\u0004 \u0000*\u0006\u0008\u0004\u0010\u0005 \u0000*\u0006\u0008\u0005\u0010\u0006 \u00012\u0008\u0012\u0004\u0012\u0002H\u00060\u0007J6\u0010\u0008\u001a\u00028\u00052\u0006\u0010\t\u001a\u00028\u00002\u0006\u0010\n\u001a\u00028\u00012\u0006\u0010\u000b\u001a\u00028\u00022\u0006\u0010\u000c\u001a\u00028\u00032\u0006\u0010\r\u001a\u00028\u0004H\u00a6\u0002\u00a2\u0006\u0002\u0010\u000e\u00a8\u0006\u000f"
    }
    d2 = {
        "Lkotlin/jvm/functions/Function5;",
        "P1",
        "P2",
        "P3",
        "P4",
        "P5",
        "R",
        "Lkotlin/Function;",
        "invoke",
        "p1",
        "p2",
        "p3",
        "p4",
        "p5",
        "(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation


# virtual methods
.method public abstract invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(TP1;TP2;TP3;TP4;TP5;)TR;"
        }
    .end annotation
.end method
