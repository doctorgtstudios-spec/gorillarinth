###### Class kotlin.jvm.internal.markers.KMutableList (kotlin.jvm.internal.markers.KMutableList)
.class public interface abstract Lkotlin/jvm/internal/markers/KMutableList;
.super Ljava/lang/Object;
.source "KMarkers.kt"

# interfaces
.implements Lkotlin/jvm/internal/markers/KMutableCollection;


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u0008f\u0018\u00002\u00020\u0001\u00a8\u0006\u0002"
    }
    d2 = {
        "Lkotlin/jvm/internal/markers/KMutableList;",
        "Lkotlin/jvm/internal/markers/KMutableCollection;",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x1,
        0x9,
        0x0
    }
    xi = 0x30
.end annotation
